<?php

$conn=mysqli_connect("localhost","root","","harrylogin");
if($conn==false){
    die('Error : cannot connect');
}

?>